// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:like_button/like_button.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: LikeButton(
          // circleSize: 300,
          // animationDuration: Duration(milliseconds: 1000),
          size: 100,
          likeCount: 45,
          countPostion: CountPostion.bottom,
          
        ),
      ),
    );
  }
}
